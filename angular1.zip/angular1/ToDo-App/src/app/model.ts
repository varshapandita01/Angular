export class TodoModel{
    public email;
    public password;
    public status="incomplete";
    public name;
}