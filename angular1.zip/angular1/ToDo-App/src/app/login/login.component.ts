import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';
import { TodoModel } from '../model';
import { RegisterLoginService } from '../service/register-login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
//to create new employee or edit it
@Input() employee :TodoModel
constructor(private empService: RegisterLoginService) {
  this.employee=new TodoModel();
 /* this.employee.email="admin@administrator.com"
  this.employee.password="123456"
  if(this.employee.email=="admin@administrator.com" && this.employee.password==12345){
      this.add();
  }
  else{
    
  }*/
}

ngOnInit() {
}
add() {
 
  this.empService.add(this.employee);
  console.log(this.employee);
  this.employee = new TodoModel();
}

}

