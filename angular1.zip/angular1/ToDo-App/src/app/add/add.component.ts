import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TodoModel } from '../model';
import { RegisterLoginService } from '../service/register-login.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
 //to create new employee or edit it
 @Input() customer: TodoModel;

 //removes register page after upadting the data
 @Output() edited = new EventEmitter();
 
 // to control update button in form
 @Input() isEditing: boolean;

      //initilize it
 constructor(private custService: RegisterLoginService) {
   this.customer = new TodoModel();
 }

 addTask() {
   
   this.custService.addTask(this.customer);
   console.log(this.customer);
   this.customer = new TodoModel();
 }

 
 update()
 {
   this.isEditing = false;
   this.customer = new TodoModel();
   this.edited.emit();
 }
 ngOnInit() {
 }


}
