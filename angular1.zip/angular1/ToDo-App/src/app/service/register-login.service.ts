import { Injectable } from '@angular/core';
import { TodoComponent } from '../todo/todo.component';
import { TodoModel } from '../model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RegisterLoginService {

  employeeArr: TodoModel[];
    
    constructor(private routes:Router) {
      this.employeeArr = [];
    }
  
    add(employee: TodoModel) {
      this.employeeArr.push(employee);
      this.routes.navigate(['/todo']);
    }

    getEmployees() {
      return this.employeeArr;
    }
    addTask(employee: TodoModel) {
      this.employeeArr.push(employee);
      this.routes.navigate(['/todo']);
    }

    edit(name: string) {
      return this.employeeArr.find(x => x.name == name);
    }
    delete(index: number) {
      this.employeeArr.splice(index, 1);
    }
}
