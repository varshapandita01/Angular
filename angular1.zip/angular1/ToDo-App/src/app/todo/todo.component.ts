import { Component, OnInit } from '@angular/core';
import { TodoModel } from '../model';
import { RegisterLoginService } from '../service/register-login.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  customerArr:TodoModel[];
  customerToEdit:TodoModel;
  isEditing:boolean;

  constructor(private empService:RegisterLoginService) { 
    this.customerArr = [];
    this.customerToEdit = new TodoModel()
    
  }

  ngOnInit() {
    this.customerArr = this.empService.getEmployees();
  }
  delete(index: number) {
    confirm('Are you sure you want to delete');
    this.empService.delete(index);
   }
 
   edit(name:string)
   { 
    prompt('Are you sure you want to edit');
     this.isEditing = true;
     this.customerToEdit = this.empService.edit(name);
   }
  

}
