import { Injectable } from '@angular/core';
import { EmployeeModel } from '../model/Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
//create array
employeeArr:EmployeeModel[]
//generate id
static counter:number =1001;
//initiase this in constructor
  constructor() { 
    
    this.employeeArr=[]
  }

  //add employee logic
  add(employee:EmployeeModel){
    employee.employeeId = EmployeeService.counter++;
    this.employeeArr.push(employee)
  }
  display()
  {
    return this.employeeArr //data having array is returned to display
  }
}
