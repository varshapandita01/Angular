export class EmployeeModel{
    public employeeId;
    public employeeName;
    public employeeGender;
    public employeeSalary;
    public employeeDept; 
    public employeeEmail;
    public employeeMobile;
}