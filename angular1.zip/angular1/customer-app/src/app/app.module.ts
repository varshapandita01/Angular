import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { DisplayComponent } from './display/display.component';
import { SearchComponent } from './search/search.component';
import {RouterModule, Routes} from '@angular/router';
import { CustomerService } from './services/customer.service';



const routes:Routes = [
  {path:'',redirectTo:'',pathMatch: 'full'},
  {path:'register',component: RegisterComponent},
  {path:'display',component: DisplayComponent},
  {path:'search',component: SearchComponent},
  {path:'**',redirectTo:'/register',pathMatch:'full'}
  ];
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    DisplayComponent,
    SearchComponent,
 
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(routes),FormsModule
  ],
  providers: [CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
