export class CustomerModel{
   public id:number;
   public name:string;
   public mobile:number;
   public email:string;

}