import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CustomerService } from '../services/customer.service';
import { CustomerModel } from '../model/customer';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  //to create new employee or edit it
  @Input() customer: CustomerModel;

  //removes register page after upadting the data
  @Output() edited = new EventEmitter();
  
  // to control update button in form
  @Input() isEditing: boolean;

       //initilize it
  constructor(private custService: CustomerService) {
    this.customer = new CustomerModel();
  }

  add() {
    this.custService.add(this.customer);
    console.log(this.customer);
    this.customer = new CustomerModel();
  }

  
  update()
  {
    this.isEditing = false;
    this.customer = new CustomerModel();
    this.edited.emit();
  }
  ngOnInit() {
  }

}
