import { Injectable } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

export class CustomerService {

    customerArr: CustomerModel[];
    
    constructor(private routes:Router) {
      this.customerArr = [];
    }
  
    add(customer: CustomerModel) {
        customer.id = Math.floor(Math.random() * 100);
      this.customerArr.push(customer);
      this.routes.navigate(['/display']);
    }
   
    getEmployees() {
      return this.customerArr;
    }
    edit(id: number) {
      return this.customerArr.find(x => x.id == id);
    }
    delete(index: number) {
      this.customerArr.splice(index, 1);
    }

    searchCust(id: number) {
      var result = this.customerArr.find(x => x.id == id);
      if (result == null)
        return null; //if not found
      else
        return result; //if found then store it
    }

    sortCust() {
      this.customerArr.sort((a, b) =>( a.id > b.id ? 1 : ((a.id < b.id) ? -1 : 0))
                       );
      return this.customerArr;
    }

    
}