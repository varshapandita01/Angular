import { Injectable } from '@angular/core';
import { EmployeeModel } from '../models/Employee';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employeeArr: EmployeeModel[];
  
  constructor(private routes:Router) {
    this.employeeArr = [];
  }

  add(employee: EmployeeModel) {
    employee.employeeId = Math.floor(Math.random() * 100);
    this.employeeArr.push(employee);
    this.routes.navigate(['/display']);
  }

  getEmployees() {
    return this.employeeArr;
  }

  delete(index: number) {
    this.employeeArr.splice(index, 1);
  }
  searchEmp(id: number) {
    var result = this.employeeArr.find(x => x.employeeId == id);
    if (result == null)
      return null; //if not found
    else
      return result; //if found then store it
  }


  sortEmpByName()
  {
    this.employeeArr.sort((a,b)=>a.employeeName.localeCompare(b.employeeName.valueOf()));
    return this.employeeArr;
  }

  sortEmpBySalary() {
    this.employeeArr.sort((a, b) => a.employeeSalary - b.employeeSalary);
    return this.employeeArr;
  }

  edit(id: number) {
    return this.employeeArr.find(x => x.employeeId == id);
  }
}
