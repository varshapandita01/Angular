import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EmployeeModel } from '../models/Employee';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {

  //to create new employee or edit it
  @Input() employee: EmployeeModel;

  // to control update button in form
  @Input() isEditing: boolean;

  @Output() edited = new EventEmitter();

  //initilize it
  constructor(private empService: EmployeeService) {
    this.employee = new EmployeeModel();
  }

  add() {
    this.empService.add(this.employee);
    this.employee = new EmployeeModel();
  }

  update()
  {
    this.isEditing = false;
    this.employee = new EmployeeModel();
    this.edited.emit();
  }
}
